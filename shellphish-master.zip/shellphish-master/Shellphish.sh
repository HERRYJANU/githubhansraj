$ pkg install git
$ pkg install python2
$ pkg install php
$ pkg install curl
$ git clone https://github.com/herryjanu/shellphish.git
$ cd shellphish
chmod +x shellphish.sh
$ ls
bash shellphish.sh
